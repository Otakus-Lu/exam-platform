package com.xinyue.dao;

import java.util.List;

import com.xinyue.model.Title;

public interface ITitleDAO {

	public void save(Title title) ;
	public void delete(Title title);
	public void deleteById(int tid);
	public Title update(Title title);
	public Title findById(int tid);
	public List<Title> findAll();
	public void setAuto_increment(int id);
	public List<Title> findByCourse(String course);
	
}
