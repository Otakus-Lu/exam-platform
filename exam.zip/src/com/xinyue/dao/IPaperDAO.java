package com.xinyue.dao;

import java.util.List;

import com.xinyue.model.Paper;

public interface IPaperDAO {

	public void save(Paper paper);
	public void delete(Paper paper);
	public Paper update(Paper paper);
	public Paper findById(int pid);
	public List<Paper> findAll();
	public void deleteById(int tid);
}
