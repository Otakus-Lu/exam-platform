package com.xinyue.dao;

import java.util.List;

import com.xinyue.exception.StudentExistException;
import com.xinyue.model.User;

public interface IUserDAO {

	
	public boolean save(User user)throws StudentExistException;
	public boolean delete(User user);
	public User update(User user);
	public User findById(int uid);
	public List<User> findAll();
	public void deleteById(int tid);
	public void setAuto_increment(int id);
	
	
}
