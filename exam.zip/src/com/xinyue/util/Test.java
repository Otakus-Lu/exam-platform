package com.xinyue.util;
//����ʱ
public class Test extends Thread{
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println(timeDown(1));
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	@SuppressWarnings("static-access")
	public static boolean timeDown(int time) throws InterruptedException{
		for (int j = 1; j <=time; j++) {

			for (int i = 0; i <= 59; i++) {
				new Thread().sleep(1000);
				int sec = 59 - i;
				if (sec < 10) {

					System.out.println((time - j) + ":" + ("0" + sec));
				}
				else
					System.out.println((time - j) + ":" + (sec));
			}
		}
		return false;
	}
}
