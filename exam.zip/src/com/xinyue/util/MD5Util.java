package com.xinyue.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/*MD5���ܹ�����*/
public class MD5Util {
	public static String md5(String str) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(str.getBytes());
			byte[] md5 = md.digest();
			char[] ch = "0123456789abcdef".toCharArray();
			StringBuilder buf = new StringBuilder();
			for (byte b : md5) {
				buf.append(ch[b >>> 4 & 0xf]);
				buf.append(ch[b & 0xf]);
			}
			return buf.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) {
		System.out.println(md5("admin"));
	}

}
