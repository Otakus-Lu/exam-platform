package com.xinyue.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.xinyue.exception.StudentExistException;
import com.xinyue.model.Paper;
import com.xinyue.model.User;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.UserManageImp;

public class ImportUser {

	// ע��UserManageImp
	private UserManage userManage = new UserManageImp();

	// �õ�User
	public List<User> getStudents() throws IOException {

		List<User> list1 = new ArrayList<User>();
		InputStreamReader isr = new InputStreamReader(new FileInputStream(
				new File("user.txt")));

		BufferedReader br = new BufferedReader(isr);

		String str = null;
		while (true) {

			str = br.readLine();
			if (str == null)
				break;
			String[] strUser = str.split(":");
			User user = new User();

			int uid = Integer.parseInt(strUser[0]);
			String name = strUser[1];
			String password = strUser[2];
			Paper paper = null;

			user.setUid(uid);
			user.setName(name);
			user.setPassword(password);
			user.setPaper(paper);
			list1.add(user);
		}
		isr.close();
		return list1;
	}

	// �������ݿ�
	public boolean insertUser(List<User> listUser) throws StudentExistException {

		for (int i = 0; i < listUser.size(); i++) {

			User user = listUser.get(i);
			userManage.save(user);
		}
		return true;
	}

}
