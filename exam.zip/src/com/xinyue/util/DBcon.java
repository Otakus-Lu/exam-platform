package com.xinyue.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



//����ģʽ�����ݿ�������
public class DBcon {
	/*
	 * Class.forName("oracle.jdbc.driver.OracleDriver");//����oracle������������������������·��
	 * 
	 * String url = "jdbc:oracle:thin:@MyDbComputerNameOrIP:1521:ORCL
	 */

	private static DBcon dbcon = null;

	private DBcon() {

		String diver = "com.mysql.jdbc.Driver";
		// String diver = "oracle.jdbc.driver.OracleDriver";

		try {
			Class.forName(diver);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static DBcon getDBcon() throws Exception {

		if (null == dbcon) {

			dbcon = new DBcon();
		}

		return dbcon;
	}

	public Connection getConnection() {
		Connection con = null;
		String url = "jdbc:mysql://localhost:3306/exam?serverTimezone=Asia/Shanghai&useUnicode=true&amp;characterEncoding=utf8";
		try {
			con = DriverManager.getConnection(url, "root", "admin");
			// con = DriverManager.getConnection(url, "scott", "tiger");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

}
