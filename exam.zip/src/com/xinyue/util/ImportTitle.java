package com.xinyue.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.xinyue.exception.StudentExistException;
import com.xinyue.model.Title;
import com.xinyue.service.TitleManage;
import com.xinyue.serviceimp.TitleManageImp;

public class ImportTitle {

	// ע��TitleManageImp
	private TitleManage titleManage = new TitleManageImp();

	// �õ�User
	public List<Title> getTitles() throws IOException {

		List<Title> list1 = new ArrayList<Title>();
		InputStreamReader isr = new InputStreamReader(new FileInputStream(
				new File("title.txt")));

		BufferedReader br = new BufferedReader(isr);

		String str = null;
		while (true) {

			str = br.readLine();
			if (str == null)
				break;
			String[] strUser = str.split(":");
			Title title = new Title();
System.out.println(Arrays.toString(strUser));
			String question = strUser[0];
			String option = strUser[1];
			String key = strUser[2].trim();
			//System.out.println(strUser[3]);
			System.out.println(strUser[3]);
			int level = Integer.parseInt(strUser[3].trim());
			int score = Integer.parseInt(strUser[4].trim());
			String course=strUser[5];

			title.setQuestion(question);
			title.setOption(option);
			title.setKey(key);
			title.setLevel(level);
			title.setScore(score);
			title.setCourse(course);
			list1.add(title);
		}
		isr.close();
		return list1;
	}

	// �������ݿ�
	public boolean insertTitle(List<Title> listTitle)
			throws StudentExistException {

		for (int i = 0; i < listTitle.size(); i++) {

			Title title = listTitle.get(i);
			titleManage.save(title);
		}
		return true;
	}

}
