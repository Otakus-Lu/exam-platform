package com.xinyue.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.xinyue.dao.IPaperDAO;
import com.xinyue.model.Paper;
import com.xinyue.util.DBcon;

public class PaperDAO implements IPaperDAO {

	@Override
	public void delete(Paper paper) {

		int pid = paper.getPid();
		String delSql = "delete from t_paper where pid=" + pid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List<Paper> findAll() {
		List<Paper> listPaper = new ArrayList<Paper>();

		String findSql = "select * from t_paper";
		try {

			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Paper paper = new Paper();
				paper.setPid(rs.getInt("pid"));
				paper.setQuestionNum(rs.getInt("questionNum"));
				paper.setCourse(rs.getString("course"));
				paper.setListTitle(rs.getString("listTitle"));
				paper.setListAnswer(rs.getString("listAnswer"));
				paper.setPoint(rs.getInt("point"));
				paper.setTime(rs.getInt("time"));
				paper.setUserPoint(rs.getInt("userPoint"));

				listPaper.add(paper);

			}
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return listPaper;
	}

	@Override
	public Paper findById(int pid) {
		String findSql = "select * from t_paper where pid=" + pid;
		Paper paper = new Paper();
		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				paper.setPid(pid);
				paper.setQuestionNum(rs.getInt("questionNum"));
				paper.setCourse(rs.getString("course"));
				paper.setListTitle(rs.getString("listTitle"));
				paper.setListAnswer(rs.getString("listAnswer"));
				paper.setPoint(rs.getInt("point"));
				paper.setTime(rs.getInt("time"));
				paper.setUserPoint(rs.getInt("userPoint"));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return paper;
	}

	@Override
	public void save(Paper paper) {
		// TODO Auto-generated method stub

		String saveSql = "insert into t_paper values(?,?,?,?,?,?,?,?)";

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(saveSql);
			// ps.setInt(1, title.getTid());
			ps.setInt(1, paper.getPid());
			ps.setString(2, paper.getCourse());
			ps.setInt(3, paper.getQuestionNum());
			ps.setInt(4, paper.getTime());
			ps.setInt(5, paper.getPoint());
			ps.setString(6, paper.getListTitle());
			ps.setString(7, paper.getListAnswer());
			ps.setInt(8, paper.getUserPoint());
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public Paper update(Paper paper) {
		int pid = paper.getPid();
		String courose = paper.getCourse();
		int questionNum = paper.getQuestionNum();
		int time = paper.getTime();
		int point = paper.getPoint();
		String listTitle = paper.getListTitle();
		String listAnswer = paper.getListAnswer();
		int userPoint = paper.getUserPoint();
		System.out.println(listAnswer);
		System.out.println(userPoint);
		String updateSql = "update t_paper set course='" + courose
				+ "',questionNum=" + questionNum + ",time=" + time + ",point="
				+ point + ",listTitle='" + listTitle + "',listAnswer='"
				+ listAnswer + "',userPoint=" + userPoint + " where pid=" + pid;
		
		System.out.println(updateSql);
		Connection con;
		try {
			con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(updateSql);
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return paper;
	}

	@Override
	public void deleteById(int tid) {
		// TODO Auto-generated method stub
		String delSql = "delete from t_paper where pid=" + tid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
