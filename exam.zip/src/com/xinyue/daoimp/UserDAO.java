package com.xinyue.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.xinyue.dao.IPaperDAO;
import com.xinyue.dao.IUserDAO;
import com.xinyue.exception.StudentExistException;
import com.xinyue.model.Paper;
import com.xinyue.model.User;
import com.xinyue.util.DBcon;

public class UserDAO implements IUserDAO {

	private IPaperDAO ipaperDAO = new PaperDAO();

	public static void main(String[] args) throws StudentExistException {
		User st = new User();
		st.setName("111");
		st.setPassword("111");

		new UserDAO().update(st);

	}

	@Override
	public boolean delete(User user) {

		int uid = user.getUid();
		String delSql = "delete from t_user where uid=" + uid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public User findById(int id) {

		String findSql = "select * from t_user where uid=" + id;
		User user = new User();
		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String name = rs.getString(2);
				String password = rs.getString(3);
				int paperId = rs.getInt(4);

				user.setUid(id);
				user.setName(name);
				user.setPassword(password);
				user.setPaper(ipaperDAO.findById(paperId));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean save(User user) throws StudentExistException {
		int uid = user.getUid();
		User user1 = findById(uid);

		if (null != user1.getName())
			throw new StudentExistException("��ѧ���Ѵ���");

		String saveSql = "insert into t_user values(?,?,?,?)";

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(saveSql);

			// paperDAO.save(user.getPaper());
			ps.setString(1, null);
			ps.setString(2, user.getName());
			ps.setString(3, user.getPassword());
			System.out.println(user.getName());

			ps.setString(4, null);
			ps.executeUpdate();
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public User update(User user) {

		int uid = user.getUid();
		String name = user.getName();
		String password = user.getPassword();
		Paper paper = user.getPaper();
		String updateSql;
		if (user.getPaper() == null||paper.getPid()==0) {
			String strInfo = null;
			updateSql = "update t_user set name='" + name + "',password='"
					+ password + "',paperId=" + strInfo + " where uid=" + uid;
		} else {
			updateSql = "update t_user set name='" + name + "',password='"
					+ password + "',paperId=" + paper.getPid() + " where uid="
					+ uid;
		}
		System.out.println(updateSql);
		Connection con;
		try {
			con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(updateSql);
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

	public List<User> findAll() {
		List<User> listUser = new ArrayList<User>();

		String findSql = "select * from t_user";
		try {

			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				User user = new User();
				user.setUid(rs.getInt("uid"));
				user.setName(rs.getString("name"));
				user.setPassword(rs.getString("password"));
				user.setPaper(ipaperDAO.findById(rs.getInt("paperId")));

				listUser.add(user);

			}
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return listUser;
	}

	@Override
	public void deleteById(int tid) {

		String delSql = "delete from t_user where uid=" + tid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void setAuto_increment(int id) {
		String sql = "alter table t_user auto_increment = "+id;
		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
