package com.xinyue.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.xinyue.dao.ITitleDAO;
import com.xinyue.model.Title;
import com.xinyue.util.DBcon;

public class TitleDAO implements ITitleDAO {

	public void delete(Title title) {
		int tid = title.getTid();
		String delSql = "delete from t_title where tid=" + tid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public Title findById(int tid) {

		String findSql = "select * from t_title where tid=" + tid;
		Title tit = new Title();
		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String question = rs.getString(2);
				String option = rs.getString(3);
				String key = rs.getString(4);
				int level=rs.getInt(5);
				int score=rs.getInt(6);
				String course=rs.getString(7);
				tit.setTid(tid);
				tit.setQuestion(question);
				tit.setOption(option);
				tit.setKey(key);
				tit.setLevel(level);
				tit.setScore(score);
				tit.setCourse(course);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return tit;
	}

	@Override
	public void save(Title title) {

	

		String saveSql = "insert into t_title values(?,?,?,?,?,?,?)";

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(saveSql);
			ps.setString(1, null);
			ps.setString(2, title.getQuestion());
			ps.setString(3, title.getOption());
			ps.setString(4, title.getKey());
			ps.setInt(5, title.getLevel());
			ps.setInt(6, title.getScore());
			ps.setString(7, title.getCourse());
			ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public Title update(Title title) {
		int id = title.getTid();
		String question = title.getQuestion();
		String option = title.getOption();
		String key = title.getKey();
		int level=title.getLevel();
		int score=title.getScore();
		String course=title.getCourse();
		String updateSql = "update t_title set question='" + question
				+ "',toption='" + option + "',tkey='" + key + "',level="+level+",score="+score+",course='" +course+"' where tid="
				+ id;
		System.out.println(updateSql);
		Connection con;
		try {
			con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(updateSql);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return title;
	}

	
	public List<Title> findAll() {

		List<Title> listTitle = new ArrayList<Title>();

		String findSql = "select * from t_title";
		try {

			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);

			ResultSet rs = ps.executeQuery();

			
			while (rs.next()) {
				Title title =new Title();
				
				title.setTid(rs.getInt(1));
				title.setQuestion(rs.getString(2));
				title.setOption(rs.getString(3));
				title.setKey(rs.getString(4));
				title.setLevel(rs.getInt(5));
				title.setScore(rs.getInt(6));
				title.setCourse(rs.getString(7));
				listTitle.add(title);
				
			}
			con.close();
			return listTitle;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return listTitle;
	}

	@Override
	public void deleteById(int tid) {
		// TODO Auto-generated method stub
		String delSql = "delete from t_title where tid=" + tid;

		try {
			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(delSql);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void setAuto_increment(int id) {
		// TODO Auto-generated method stub
		String sql = "alter table t_title auto_increment ="+id;
		Connection con;
		try {
			con = DBcon.getDBcon().getConnection();
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Title> findByCourse(String course) {

		List<Title> listTitle = new ArrayList<Title>();

		String findSql = "select * from t_title where course='"+course+"'";
		System.out.println(findSql);
		try {

			Connection con = DBcon.getDBcon().getConnection();
			PreparedStatement ps = con.prepareStatement(findSql);

			ResultSet rs = ps.executeQuery();

			
			while (rs.next()) {
				Title title =new Title();
				
				title.setTid(rs.getInt(1));
				title.setQuestion(rs.getString(2));
				title.setOption(rs.getString(3));
				title.setKey(rs.getString(4));
				title.setLevel(rs.getInt(5));
				title.setScore(rs.getInt(6));
				title.setCourse(rs.getString(7));
				listTitle.add(title);
				
			}
			con.close();
			return listTitle;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return listTitle;
	}

}
