package com.xinyue.serviceimp;

import java.util.List;

import com.xinyue.dao.ITitleDAO;
import com.xinyue.daoimp.TitleDAO;
import com.xinyue.model.Title;
import com.xinyue.service.TitleManage;

public class TitleManageImp implements TitleManage {

	private ITitleDAO ititleDAO=new TitleDAO();

	@Override
	public void delete(Title title) {
		ititleDAO.delete(title);
	}

	@Override
	public List<Title> findAll() {
		// TODO Auto-generated method stub
		return ititleDAO.findAll();
	}

	@Override
	public Title findById(int tid) {
		// TODO Auto-generated method stub
		return ititleDAO.findById(tid);
	}

	@Override
	public void save(Title title) {
		// TODO Auto-generated method stub
		ititleDAO.save(title);
	}

	@Override
	public void update(Title title) {
		// TODO Auto-generated method stub
		ititleDAO.update(title);
	}

	@Override
	public void deleteById(int tid) {
		// TODO Auto-generated method stub
		ititleDAO.deleteById(tid);
		
	}

	@Override
	public void setAuto_increment(int id) {
		ititleDAO.setAuto_increment(id);
	}

	@Override
	public List<Title> findByCourse(String course) {
		// TODO Auto-generated method stub
		return ititleDAO.findByCourse(course);
	}

}
