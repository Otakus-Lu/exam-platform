package com.xinyue.serviceimp;

import java.util.List;

import com.xinyue.dao.IPaperDAO;
import com.xinyue.daoimp.PaperDAO;
import com.xinyue.model.Paper;
import com.xinyue.service.PaperManage;

public class PaperManageImp implements PaperManage{
	private IPaperDAO ipaperDAO=new PaperDAO();
	@Override
	public void delete(Paper paper) {
		// TODO Auto-generated method stub
		ipaperDAO.delete(paper);
	}

	@Override
	public List<Paper> findAll() {
		// TODO Auto-generated method stub
		return ipaperDAO.findAll();
	}

	@Override
	public Paper findById(int pid) {
		// TODO Auto-generated method stub
		return ipaperDAO.findById(pid);
	}

	@Override
	public void save(Paper paper) {
		// TODO Auto-generated method stub
		ipaperDAO.save(paper);
	}

	@Override
	public void update(Paper paper) {
		// TODO Auto-generated method stub
		ipaperDAO.update(paper);
	}

	@Override
	public void deleteById(int tid) {
		// TODO Auto-generated method stub
		ipaperDAO.deleteById(tid);
	}

}
