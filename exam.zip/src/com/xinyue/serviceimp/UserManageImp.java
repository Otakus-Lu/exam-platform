package com.xinyue.serviceimp;

import java.util.List;

import com.xinyue.dao.IUserDAO;
import com.xinyue.daoimp.UserDAO;
import com.xinyue.exception.StudentExistException;
import com.xinyue.model.User;
import com.xinyue.service.UserManage;

public class UserManageImp implements UserManage{

	private IUserDAO iuserDAO=new UserDAO();
	
	

	@Override
	public void delete(User user) {
		iuserDAO.delete(user);
	}

	@Override
	public List<User> findAll() {
		return iuserDAO.findAll();
	}

	@Override
	public User findById(int uid) {
		// TODO Auto-generated method stub
		return iuserDAO.findById(uid);
	}

	@Override
	public void save(User user) throws StudentExistException {
		// TODO Auto-generated method stub
		iuserDAO.save(user);
	}

	@Override
	public void update(User user) {
		iuserDAO.update(user);
	}

	@Override
	public void deleteById(int tid) {
		
		// TODO Auto-generated method stub
		
		iuserDAO.deleteById(tid);
	}

	@Override
	public void setAuto_increment(int id) {
		// TODO Auto-generated method stub
		iuserDAO.setAuto_increment(id);
	}

	
}
