package com.xinyue.exception;

public class StudentExistException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StudentExistException(String str) {
		super(str);
	}
}
