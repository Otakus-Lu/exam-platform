package com.xinyue.clientUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.border.LineBorder;

import com.xinyue.model.Paper;
import com.xinyue.service.PaperManage;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.PaperManageImp;
import com.xinyue.serviceimp.UserManageImp;


@SuppressWarnings("serial")
public class WelcomeFrame extends JWindow {

	private PaperManage paperManage=new PaperManageImp();
	private UserManage userManage=new UserManageImp();
	int uid;

	public WelcomeFrame(int uid) {
		init();
		this.uid=uid;
	}

	private void init() {
		setSize(800, 470);
		setContentPane(createContentPane());
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension win = tool.getScreenSize();
		int x = (int) (win.getWidth() / 2 - this.getWidth() / 2);
		int y = (int) (win.getHeight() / 2 - this.getHeight() / 2);
		this.setLocation(x, y);
		this.setVisible(true);
		//System.out.println(this instanceof WelcomeFrame);
		new Thread() {
			public void run() {
				try {
					Thread.sleep(3000);
					setVisible(false);
					
					if(paperManage.findById(uid).getListAnswer()==null){
						new ExamClient(uid);
					}
					else{
						Paper p=paperManage.findById(uid);
						JOptionPane.showMessageDialog(WelcomeFrame.this, userManage.findById(uid).getName()+" ���Ѿ�����"+p.getCourse()+",�÷�Ϊ��"+p.getUserPoint());
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			};
		}.start();

	}

	private JPanel createContentPane() {
		JPanel p = new JPanel();
		JLabel l = new JLabel();
		p.setBorder(new LineBorder(Color.gray));
		l.setIcon(new ImageIcon(getClass().getResource("exam1.jpg")));
		p.add(l);
		return p;
	}

}
