package com.xinyue.clientUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import com.xinyue.model.User;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.UserManageImp;
import com.xinyue.util.MD5Util;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class ChangePasswordFrame extends javax.swing.JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//ע��
	private UserManage userManage=new UserManageImp();
	private JPanel jPanel1;
	private JButton jButton1;
	private JLabel jLabel5;
	private JPasswordField jPasswordField2;
	private JPasswordField jPasswordField1;
	private JTextField jTextField2;
	private JLabel jLabel4;
	private JLabel jLabel3;
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JButton jButton2;

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ChangePasswordFrame inst = new ChangePasswordFrame();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public ChangePasswordFrame() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1);
				jPanel1.setBounds(0, 0, 485, 343);
				jPanel1.setLayout(null);
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u786e\u8ba4");
					jButton1.setBounds(182, 261, 52, 30);
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u91cd\u7f6e");
					jButton2.setBounds(282, 261, 52, 30);
					jButton2.setOpaque(true);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("       \u4fee\u6539\u5bc6\u7801");
					jLabel2.setBounds(140, 20, 203, 45);
					jLabel2.setOpaque(true);
					jLabel2.setFont(new java.awt.Font("����",0,18));
				}
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8f93\u5165\u5b66\u53f7");
					jLabel1.setBounds(93, 88, 77, 18);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u8f93\u5165\u5b66\u53f7");
					jLabel3.setBounds(93, 88, 77, 18);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText("\u8f93\u5165\u65b0\u5bc6\u7801");
					jLabel4.setBounds(93, 198, 77, 18);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(182, 82, 146, 30);
				}
				{
					jLabel5 = new JLabel();
					jPanel1.add(jLabel5);
					jLabel5.setText("\u8f93\u5165\u539f\u5bc6\u7801");
					jLabel5.setBounds(93, 142, 77, 18);
				}
				{
					jPasswordField1 = new JPasswordField();
					jPanel1.add(jPasswordField1);
					jPasswordField1.setBounds(182, 140, 147, 28);
				}
				{
					jPasswordField2 = new JPasswordField();
					jPanel1.add(jPasswordField2);
					jPasswordField2.setBounds(182, 189, 147, 28);
				}
			}
			
			
			
			pack();
			this.setSize(501, 376);
			setLocationRelativeTo(null);
			setVisible(true);
			jButton1.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stube
					int uid=Integer.parseInt(jTextField2.getText());
					String password=MD5Util.md5(new String(jPasswordField1.getPassword()));
					User user=userManage.findById(uid);
					if(password.equals(user.getPassword())){
						
						String newPassword=MD5Util.md5(new String(jPasswordField2.getPassword()));
						user.setPassword(newPassword);
						userManage.update(user);
						JOptionPane.showMessageDialog(ChangePasswordFrame.this,"��ϲ:"+user.getName()+"��������޸ĳɹ�");
					}
					else
						JOptionPane.showMessageDialog(jButton1, "ԭʼ�������");
				}
			});
			jButton2.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					jPasswordField1.setText("");
					jPasswordField2.setText("");
					
				}
			});
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
