package com.xinyue.clientUI;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import com.xinyue.model.Paper;
import com.xinyue.model.Title;
import com.xinyue.model.User;
import com.xinyue.service.PaperManage;
import com.xinyue.service.TitleManage;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.PaperManageImp;
import com.xinyue.serviceimp.TitleManageImp;
import com.xinyue.serviceimp.UserManageImp;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
@SuppressWarnings("serial")
public class ExamClient extends javax.swing.JFrame {

	private JPanel jPanel1;
	private JButton jButton1;
	private Checkbox jCheckBox2;
	private JLabel jLabel3;
	private JButton jButton5;
	private JScrollPane jScrollPane1;
	private static JTextArea jTextArea1;
	private Checkbox jCheckBox4;
	private JLabel jLabel2;
	private Checkbox jCheckBox3;
	private Checkbox jCheckBox1;
	private JButton jButton3;
	private JButton jButton2;
	private JLabel jLabel1;
	private static CheckboxGroup checkboxGroup = new CheckboxGroup();
	
	
	Thread th=new Thread(new Runnable() {

		@Override
		public void run() {
			try {
				b = timeDown(paperManage.findById(uid).getTime());
				if (b == false) {
					mapAnswer
					.put(i, checkboxGroup.getSelectedCheckbox().getLabel());
					for (int i = 1; i <= mapAnswer.size(); i++) {
						//�������һ���
						
						int tid2 = Integer
								.parseInt(strTitle[i - 1]);
						// ȡ��Ŀ
						Title tit = titleManage.findById(tid2);

						String key = tit.getKey();
						// System.out.println(mapAnswer.get(i) +
						// "   " + key);
						if (key.equals(mapAnswer.get(i))) {
							// System.out.println(tit.getScore());
							userPoint = userPoint + tit.getScore();
						}
					}
					JOptionPane.showMessageDialog(ExamClient.this,
							"ʱ�䵽  " + username + "��ĵ÷��ǣ�"
									+ userPoint);

					// ���� ���ύ��ť�� ���а�ťΪ������
					jButton2.setEnabled(false);
					jButton3.setEnabled(false);
					jButton5.setEnabled(false);
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	});

	// �ж�ʱ���ǲ������
	boolean b = true;

	// ע��TitleManage
	private static TitleManage titleManage = new TitleManageImp();
	// ע��UserManage
	private UserManage userManage = new UserManageImp();
	// ע��PaperManage
	private PaperManage paperManage = new PaperManageImp();
	// �û�id
	int uid;
	// �û�����
	String username;
	// ��¼�������
	static int i = 1;

	// ��ŷ���
	int userPoint = 0;
	// ʱ��
	long time;
	// ���User
	List<User> listUser;
	// ���Title
	String[] strTitle;
	// ����û���
	Map<Integer, String> mapAnswer = new HashMap<Integer, String>();

	public List<User> getList() {
		return listUser;
	}

	public void setList(List<User> listUser) {
		this.listUser = listUser;
	}

	public ExamClient(int uid) {
		super();
		this.uid = uid;
		initGUI();

	}

	private void initGUI() {

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int var = JOptionPane.showConfirmDialog(ExamClient.this,
						"ȷ���뿪��?");
				if (var == JOptionPane.YES_OPTION) {
					setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				}
			}
		});
		try {
			pack();
			this.setSize(812, 499);
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
		// ���þ��кͿɼ�
		setLocationRelativeTo(null);
		setVisible(true);
		// �̶���С
		setResizable(false);
		{
			jPanel1 = new JPanel();
			getContentPane().add(jPanel1, BorderLayout.CENTER);
			jPanel1.setLayout(null);
			jPanel1.setPreferredSize(new java.awt.Dimension(716, 455));
			jPanel1.add(getJScrollPane1());
			{
				jLabel1 = new JLabel();
				jPanel1.add(jLabel1);
				jLabel1.setBounds(77, 7, 420, 35);
				jLabel1.setFont(new java.awt.Font("����", 0, 20));
			}
			{
				jButton1 = new JButton();
				jPanel1.add(jButton1);
				jButton1.setText("��ʼ����");
				jButton1.setBounds(165, 399, 99, 23);
			}
			{
				jButton2 = new JButton();
				jPanel1.add(jButton2);
				jButton2.setText("��һ��");
				jButton2.setBounds(472, 399, 81, 23);
			}
			{
				jButton3 = new JButton();
				jPanel1.add(jButton3);
				jButton3.setText("�ύ");
				jButton3.setBounds(622, 399, 81, 23);
			}
			{
				jCheckBox1 = new Checkbox("A", checkboxGroup, true);
				jPanel1.add(jCheckBox1);
				// jCheckBox1.setText("A");
				jCheckBox1.setBounds(326, 357, 36, 27);
			}
			{
				jCheckBox2 = new Checkbox("B", checkboxGroup, false);
				jPanel1.add(jCheckBox2);
				// jCheckBox2.setText("B");
				jCheckBox2.setBounds(386, 360, 42, 21);
			}
			{
				jCheckBox3 = new Checkbox("C", checkboxGroup, false);
				jPanel1.add(jCheckBox3);
				// jCheckBox3.setText("C");
				jCheckBox3.setBounds(456, 361, 33, 19);
			}
			{
				jLabel2 = new JLabel();
				jPanel1.add(jLabel2);
				jPanel1.add(getJCheckBox4());
				jPanel1.add(getJButton5());
				jPanel1.add(getJLabel3());
				jLabel2.setText("ѡ��");
				jLabel2.setBounds(264, 362, 41, 17);
			}
		}

		// ��ʼ�����¼�
		jButton1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				username = userManage.findById(uid).getName();
				time = System.currentTimeMillis();

				// ȡ���Ծ�
				Paper paper = paperManage.findById(uid);
				strTitle = paper.getListTitle().split(",");
				// ���
				int tid1 = Integer.parseInt(strTitle[0]);
				

				showTitle(tid1);
				
				
				jButton1.setEnabled(false);
				jButton5.setEnabled(false);
				th.start();

			}
		});
		// ��һ��
		jButton2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// ���
				int tid1 = Integer.parseInt(strTitle[i]);
				// �����û���
				mapAnswer
						.put(i, checkboxGroup.getSelectedCheckbox().getLabel());
				i++;
				jLabel1.setText("�γ̣�" + paperManage.findById(uid).getCourse()
						+ ";" + username + "��Ĵ������Ϊ" + i + "/"
						+ strTitle.length);
				
				checkboxGroup.getSelectedCheckbox();

				showTitle(tid1);

				if ("A".equals(mapAnswer.get(i))) {
					jCheckBox1.setState(true);
				}

				if ("B".equals(mapAnswer.get(i))) {
					jCheckBox2.setState(true);
				}

				if ("C".equals(mapAnswer.get(i))) {
					jCheckBox3.setState(true);
				}

				if ("D".equals(mapAnswer.get(i))) {
					jCheckBox4.setState(true);
				}

				jButton5.setEnabled(true);
				if (i == strTitle.length) {
					jButton2.setEnabled(false);
				}

			}
		});
		// ��һ����¼�
		jButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �����û���
				mapAnswer
						.put(i, checkboxGroup.getSelectedCheckbox().getLabel());
				// ���

				i--;

				jLabel1.setText("�γ̣�" + paperManage.findById(uid).getCourse()
						+ ";" + username + "��Ĵ������Ϊ" + i + "/"
						+ strTitle.length);

				int tid1 = Integer.parseInt(strTitle[i]);
				// ȡ��ѧ���Ĵ𰸣����ö�Ӧѡ��Ϊ ѡ��״̬
				if ("A".equals(mapAnswer.get(i))) {
					jCheckBox1.setState(true);
				}

				if ("B".equals(mapAnswer.get(i))) {
					jCheckBox2.setState(true);
				}

				if ("C".equals(mapAnswer.get(i))) {
					jCheckBox3.setState(true);
				}

				if ("D".equals(mapAnswer.get(i))) {
					jCheckBox4.setState(true);
				}

				// System.out.println(i);
				// ��Ŀ����Ϊ1��ʱ����һ�ⰴť���Σ����� ����
				if (i == 1) {
					jButton5.setEnabled(false);
				} else {
					jButton5.setEnabled(true);
				}
				if (i != strTitle.length) {
					jButton2.setEnabled(true);
				}
				// ��ʾ��Ŀ
				showTitle(tid1);

			}
		});

		// �ύ�¼� ��ɴ𰸵��ύ����������
		jButton3.addActionListener(new ActionListener() {

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				//�������һ���
				mapAnswer
				.put(i, checkboxGroup.getSelectedCheckbox().getLabel());
				for (int i = 1; i <= mapAnswer.size(); i++) {
					

					int tid2 = Integer.parseInt(strTitle[i - 1]);
					// ȡ��Ŀ
					Title tit = titleManage.findById(tid2);

					String key = tit.getKey();
					// System.out.println(mapAnswer.get(i) + "   " + key);
					if (key.equals(mapAnswer.get(i))) {
						// System.out.println(tit.getScore());
						userPoint = userPoint + tit.getScore();
					}
				}
				JOptionPane.showMessageDialog(ExamClient.this, username
						+ "��ĵ÷��ǣ�" + userPoint);

				jLabel1.setText(username + "��ϲ��������;" + "�÷�Ϊ��" + userPoint);
				Paper paper = paperManage.findById(uid);

				String listAnswers = "" ;
				for (int i = 1; i < mapAnswer.size()+1; i++) {
					listAnswers=listAnswers+mapAnswer.get(i)+",";
				}
				paper.setUserPoint(userPoint);
				paper.setListAnswer(listAnswers.toString());
				paperManage.update(paper);
				// ���� ���ύ��ť�� ���а�ťΪ������
				jButton2.setEnabled(false);
				jButton3.setEnabled(false);
				jButton5.setEnabled(false);
				
				b=false;
				th.stop();
				jLabel3.setText("���Խ���");
			}
		});
	}

	private JTextArea getJTextArea1() {
		if (jTextArea1 == null) {
			jTextArea1 = new JTextArea();
			
			jTextArea1.setBounds(68, 50, 660, 285);
		}
		return jTextArea1;
	}

	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(68, 50, 660, 285);
			jScrollPane1.setViewportView(getJTextArea1());
		}
		return jScrollPane1;
	}

	private Checkbox getJCheckBox4() {
		if (jCheckBox4 == null) {
			jCheckBox4 = new Checkbox("D", checkboxGroup, false);
			// jCheckBox4.setText("D");
			jCheckBox4.setBounds(516, 359, 44, 22);

		}
		return jCheckBox4;
	}

	private JButton getJButton5() {
		if (jButton5 == null) {
			jButton5 = new JButton();
			jButton5.setText("\u4e0a\u4e00\u9898");
			jButton5.setBounds(338, 399, 81, 23);

		}
		return jButton5;
	}

	// ��ʾ��Ŀ״̬
	public static void showTitle(int tid) {
		Title tit = titleManage.findById(tid);
		String question = tit.getQuestion();
		String option = tit.getOption();
		StringBuffer sb = new StringBuffer();
		int level = tit.getLevel();
		// System.out.println(option);
		String option1[] = option.split(",");
		sb.append("��" + i + "��" + "��  " + question + "(�ȼ�Ϊ��" + level + ")"
				+ "\n");
		sb.append(option1[0] + " " + "\n");
		sb.append(option1[1] + "\n");
		sb.append(option1[2] + "\n");
		sb.append(option1[3] + "\n");
		jTextArea1.setText(sb.toString());

		//

	}

	private JLabel getJLabel3() {
		if (jLabel3 == null) {
			jLabel3 = new JLabel();
			jLabel3.setBounds(553, 7, 168, 35);
			jLabel3.setFont(new java.awt.Font("΢���ź�", 1, 16));
		}
		return jLabel3;
	}

	@SuppressWarnings("static-access")
	public boolean timeDown(int time) throws InterruptedException {
		for (int j = 1; j <= time; j++) {

			for (int i = 0; i <= 59; i++) {
				new Thread().sleep(1000);
				int sec = 59 - i;
				if (sec < 10) {

					jLabel3.setText("����ʣ��ʱ�䣺" + (time - j) + ":" + ("0" + sec));
				} else
					jLabel3.setText("����ʣ��ʱ�䣺" + (time - j) + ":" + (sec));
			}
		}
		return false;
	}

}
