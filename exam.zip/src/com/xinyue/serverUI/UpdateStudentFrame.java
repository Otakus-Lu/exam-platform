package com.xinyue.serverUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.xinyue.model.Paper;
import com.xinyue.model.User;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.UserManageImp;
import com.xinyue.util.MD5Util;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class UpdateStudentFrame extends javax.swing.JFrame {
	private static final long serialVersionUID = 1L;

	/**
	 * Auto-generated main method to display this JFrame
	 */

	private JButton jButton1;
	private JLabel jLabel2;
	private JTextField jTextField4;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JTextField jTextField1;
	private JButton jButton2;
	private JLabel jLabel1;
	private JLabel jLabel10;
	private JLabel jLabel7;
	private JLabel jLabel8;
	private JPanel jPanel1;
	private User user;
	private int paper;

	/**
	 * 
	 */

	// ע��UserManage
	private static UserManage userManage = new UserManageImp();

	public UpdateStudentFrame(User user, int paper2) {
		super();
		this.user = user;
		this.paper = paper2;
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1);
				jPanel1.setBounds(0, -100, 562, 458);
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u9898\u76ee\u5185\u5bb9");
					jLabel1.setBounds(67, 48, 91, 33);
				}
				{
					jLabel7 = new JLabel();
					jPanel1.add(jLabel7);
					jLabel7.setText("\u5b66\u751f\u59d3\u540d");
					jLabel7.setBounds(135, 195, 68, 17);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u4fee\u6539");
					jButton1.setBounds(226, 361, 67, 24);
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u6e05\u7a7a");
					jButton2.setBounds(351, 361, 68, 24);
				}
				{
					jLabel8 = new JLabel();
					jPanel1.add(jLabel8);
					jLabel8.setText("\u5b66\u751f\u5bc6\u7801");
					jLabel8.setBounds(135, 253, 68, 17);
				}
				{
					jLabel10 = new JLabel();
					jPanel1.add(jLabel10);
					jLabel10.setText("\u8bd5\u5377\u7f16\u53f7");
					jLabel10.setBounds(135, 307, 68, 17);
					jLabel10.setOpaque(true);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u5b66\u751f\u7f16\u53f7");
					jLabel2.setBounds(135, 123, 91, 33);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setText(user.getUid() + "");
					jTextField1.setEditable(false);
					jTextField1.setBounds(238, 128, 181, 24);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setText(user.getName());
					jTextField2.setEditable(false);
					jTextField2.setBounds(238, 192, 181, 24);
				}
				{
					jTextField3 = new JTextField();
					jPanel1.add(jTextField3);
					jTextField3.setText(user.getPassword());
					jTextField3.setBounds(238, 250, 181, 23);
				}
				{
					jTextField4 = new JTextField();
					jPanel1.add(jTextField4);
					jTextField4.setText(paper + "");
					jTextField4.setEditable(false);
					jTextField4.setBounds(238, 304, 181, 23);
				}
			}
			pack();
			this.setSize(552, 391);

			setLocationRelativeTo(null);
			setVisible(true);
			jTextField1.setEditable(false);
			jTextField4.setEditable(false);

			// �޸������¼�
			jButton1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					String name = jTextField2.getText();
					String password = MD5Util.md5(jTextField3.getText());
					User user1 = new User();
					user1.setUid(user.getUid());
					user1.setName(name);
					user1.setPassword(password);
					Paper paper1 = new Paper();
					if (paper == 0) {
						paper1 = null;
						userManage.update(user1);
					} else {
						paper1.setPid(paper);
						user1.setPaper(paper1);

						userManage.update(user1);
					}
					JOptionPane
							.showMessageDialog(UpdateStudentFrame.this, "update success!!!");
				}
			});
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}

		jButton2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jTextField3.setText("");

			}
		});

	}

}
