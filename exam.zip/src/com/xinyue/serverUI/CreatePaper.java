package com.xinyue.serverUI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import com.xinyue.model.Paper;
import com.xinyue.model.Title;
import com.xinyue.model.User;
import com.xinyue.service.PaperManage;
import com.xinyue.service.TitleManage;
import com.xinyue.service.UserManage;
import com.xinyue.serviceimp.PaperManageImp;
import com.xinyue.serviceimp.TitleManageImp;
import com.xinyue.serviceimp.UserManageImp;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class CreatePaper extends javax.swing.JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// ע��TitleManage
	private TitleManage titleManage = new TitleManageImp();
	// ע��UserManage
	private UserManage userManage = new UserManageImp();
	// ע��PaperManage
	private PaperManage paperManage = new PaperManageImp();

	private JPanel jPanel1;
	private JLabel jLabel3;
	private JButton jButton1;
	private JButton jButton2;
	private JComboBox jComboBox2;
	private JLabel jLabel2;
	private JComboBox jComboBox1;
	private JLabel jLabel1;

	/**
	 * Auto-generated main method to display this JFrame
	 */

	public CreatePaper() {
		super();
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);

				jPanel1.setPreferredSize(new java.awt.Dimension(477, 334));
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8003\u8bd5\u8bfe\u7a0b");
					jLabel1.setBounds(73, 53, 74, 42);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u8003\u8bd5\u65f6\u95f4");
					jLabel3.setBounds(73, 133, 74, 42);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u968f\u673a\u4ea7\u751f\u8bd5\u5377");
					jButton1.setBounds(73, 230, 116, 49);
				}
				{
					ComboBoxModel jComboBox1Model = new DefaultComboBoxModel(
							new Integer[] { 3, 5, 10, 15, 30 });
					jComboBox1 = new JComboBox();
					jPanel1.add(jComboBox1);
					jComboBox1.setModel(jComboBox1Model);
					jComboBox1.setBounds(177, 133, 130, 34);

				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u5206\u949f");
					jLabel2.setBounds(313, 133, 48, 34);
				}
				{
					ComboBoxModel jComboBox2Model = new DefaultComboBoxModel(
							new String[] { "JAVA SE", "MySql", "��ɢ��ѧ", "����ϵͳ",
									"���������", "����ԭ��", "C����", "C++", "�������" });
					jComboBox2 = new JComboBox();
					jPanel1.add(jComboBox2);
					jComboBox2.setModel(jComboBox2Model);
					jComboBox2.setBounds(177, 62, 130, 33);
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u5220\u9664\u8bd5\u5377");
					jButton2.setBounds(261, 230, 116, 49);

				}
			}
			pack();
			this.setSize(494, 381);
			setLocationRelativeTo(null);
			setVisible(true);
			setResizable(false);

			jButton1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {


					String course = (String) jComboBox2.getSelectedItem();
					int questionNum = 20;
					List<Title> listTitles = titleManage.findByCourse(course);
					int time = (Integer) jComboBox1.getSelectedItem();
					int point = 100;

					// System.out.println(listTitle);

					List<User> listUser = userManage.findAll();
					// ����Ա�ǵ�һ���û�
					System.out.println(listUser.size());
					System.out.println(listUser.get(0).getName());
					for (int i = 1; i < listUser.size(); i++) {

						String listTitle = getListTitle(listTitles);
						User user = listUser.get(i);

						Paper paper = new Paper();
						paper.setPid(user.getUid());
						paper.setCourse(course);
						paper.setQuestionNum(questionNum);
						paper.setTime(time);
						paper.setPoint(point);
						paper.setListTitle(listTitle);

						paperManage.save(paper);

						// �û����Ծ���ż�Ϊ�û����
						user.setPaper(paper);
						userManage.update(user);

					}
					JOptionPane.showMessageDialog(CreatePaper.this,
							"create paper success!!!");

				}

			});
			jButton2.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					List<User> listUser = userManage.findAll();
					Paper paper = new Paper();
					paper.setPid(0);
					for (int i = 1; i < listUser.size(); i++) {
						User user = listUser.get(i);

						int pid = user.getPaper().getPid();
						user.setPaper(null);
						userManage.update(user);
						Paper paper1 = paperManage.findById(pid);
						paperManage.delete(paper1);
					}
				}
			});
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}

	// �����õ��Ծ�����Ŀ�б�

	public static String getListTitle(List<Title> listTitles) {

		String listTitle = null;
		// �������5���ȼ�����Ŀ���� 1,2,3,4,5
		int title1[] = new int[1];
		int n1 = 0;
		int title2[] = new int[1];
		int n2 = 0;
		int title3[] = new int[1];
		int n3 = 0;
		int title4[] = new int[1];
		int n4 = 0;
		int title5[] = new int[1];
		int n5 = 0;
		int title6[] = new int[1];
		int n6 = 0;
		int title7[] = new int[1];
		int n7 = 0;
		int title8[] = new int[1];
		int n8 = 0;
		int title9[] = new int[1];
		int n9 = 0;
		int title10[] = new int[1];
		int n10 = 0;
		Title title = null;
		for (int i = 0; i < listTitles.size(); i++) {
			title = listTitles.get(i);
			if (title.getLevel() == 1) {
				title1[n1] = title.getTid();
				n1++;
				// ��������
				int length = title1.length;
				title1 = Arrays.copyOf(title1, length + 1);
			}

			if (title.getLevel() == 2) {
				title2[n2++] = title.getTid();
				int length = title2.length;
				title2 = Arrays.copyOf(title2, length + 1);
			}

			if (title.getLevel() == 3) {
				title3[n3++] = title.getTid();
				int length = title3.length;
				title3 = Arrays.copyOf(title3, length + 1);
			}

			if (title.getLevel() == 4) {
				title4[n4++] = title.getTid();
				int length = title4.length;
				title4 = Arrays.copyOf(title4, length + 1);
			}

			if (title.getLevel() == 5) {
				title5[n5++] = title.getTid();
				int length = title5.length;
				title5 = Arrays.copyOf(title5, length + 1);
			}
			if (title.getLevel() == 6) {
				title6[n6++] = title.getTid();
				int length = title6.length;
				title6 = Arrays.copyOf(title6, length + 1);
			}
			if (title.getLevel() == 7) {
				title7[n7++] = title.getTid();
				int length = title7.length;
				title7 = Arrays.copyOf(title7, length + 1);
			}
			if (title.getLevel() == 8) {
				title8[n8++] = title.getTid();
				int length = title8.length;
				title8 = Arrays.copyOf(title8, length + 1);
			}
			if (title.getLevel() == 9) {
				title9[n9++] = title.getTid();
				int length = title9.length;
				title9 = Arrays.copyOf(title9, length + 1);
			}
			if (title.getLevel() == 10) {
				title10[n10++] = title.getTid();
				int length = title10.length;
				title10 = Arrays.copyOf(title10, length + 1);
			}

		}
		// ȥ���������һ��0Ԫ�أ��������ݵĺ���֢��
		int len1 = title1.length;
		title1 = Arrays.copyOfRange(title1, 0, len1 - 1);

		int len2 = title2.length;
		title2 = Arrays.copyOfRange(title2, 0, len2 - 1);

		int len3 = title3.length;
		title3 = Arrays.copyOfRange(title3, 0, len3 - 1);

		int len4 = title4.length;
		title4 = Arrays.copyOfRange(title4, 0, len4 - 1);

		int len5 = title5.length;
		title5 = Arrays.copyOfRange(title5, 0, len5 - 1);

		int len6 = title6.length;
		title6 = Arrays.copyOfRange(title6, 0, len6 - 1);

		int len7 = title7.length;
		title7 = Arrays.copyOfRange(title7, 0, len7 - 1);

		int len8 = title8.length;
		title8 = Arrays.copyOfRange(title8, 0, len8 - 1);

		int len9 = title9.length;
		title9 = Arrays.copyOfRange(title9, 0, len9 - 1);

		int len10 = title10.length;
		title10 = Arrays.copyOfRange(title10, 0, len10 - 1);

		Random rd = new Random();
		// �ȼ�Ϊ1
		int index1_1 = rd.nextInt(n1);
		int index1_2;
		while (true) {
			index1_2 = rd.nextInt(n1);
			if (index1_1 != index1_2)
				break;
		}
		listTitle = index1_1 + "," + index1_2;

		// �ȼ�Ϊ2
		int index2_1 = rd.nextInt(n2);
		int index2_2;
		while (true) {
			index2_2 = rd.nextInt(n2);
			if (index2_1 != index2_2)
				break;
		}
		listTitle = index2_1 + "," + index2_2;
		// System.out.println(listTitle);
		// �ȼ�Ϊ3
		int index3_1 = rd.nextInt(n3);
		int index3_2;
		while (true) {
			index3_2 = rd.nextInt(n3);
			if (index3_1 != index3_2)
				break;
		}
		listTitle = index3_1 + "," + index3_2;
		// System.out.println(listTitle);
		// �ȼ�Ϊ4
		int index4_1 = rd.nextInt(n4);
		int index4_2;
		while (true) {
			index4_2 = rd.nextInt(n4);
			if (index4_1 != index4_2)
				break;
		}
		listTitle = index4_1 + "," + index4_2;
		// System.out.println(listTitle);
		// �ȼ�Ϊ5
		int index5_1 = rd.nextInt(n5);
		int index5_2;
		while (true) {
			index5_2 = rd.nextInt(n5);
			if (index5_1 != index5_2)
				break;
		}
		// �ȼ�Ϊ6
		int index6_1 = rd.nextInt(n6);
		int index6_2;
		while (true) {
			index6_2 = rd.nextInt(n6);
			if (index6_1 != index6_2)
				break;
		}
		// �ȼ�Ϊ7
		int index7_1 = rd.nextInt(n7);
		int index7_2;
		while (true) {
			index7_2 = rd.nextInt(n7);
			if (index7_1 != index7_2)
				break;
		}
		// �ȼ�Ϊ8
		int index8_1 = rd.nextInt(n8);
		int index8_2;
		while (true) {
			index8_2 = rd.nextInt(n8);
			if (index8_1 != index8_2)
				break;
		}
		// �ȼ�Ϊ9
		int index9_1 = rd.nextInt(n9);
		int index9_2;
		while (true) {
			index9_2 = rd.nextInt(n9);
			if (index9_1 != index9_2)
				break;
		}
		// �ȼ�Ϊ10
		int index10_1 = rd.nextInt(n10);
		int index10_2;
		while (true) {
			index10_2 = rd.nextInt(n10);
			if (index10_1 != index10_2)
				break;
		}
		/*
		 * System.out.println(index1_1 + "," + index1_2 + "," + index2_1 + "," +
		 * index2_2 + "," + index3_1 + "," + index3_2 + "," + index4_1 + "," +
		 * index4_2 + "," + index5_1 + "," + index5_2);
		 */

		listTitle = title1[index1_1] + "," + title1[index1_2] + ","
				+ title2[index2_1] + "," + title2[index2_2] + ","
				+ title3[index3_1] + "," + title3[index3_2] + ","
				+ title4[index4_1] + "," + title4[index4_2] + ","
				+ title5[index5_1] + "," + title5[index5_2] + ","
				+ title6[index6_1] + "," + title6[index6_2] + ","
				+ title7[index7_1] + "," + title7[index7_2] + ","
				+ title8[index8_1] + "," + title8[index8_2] + ","
				+ title9[index9_1] + "," + title9[index9_2] + ","
				+ title10[index10_1] + "," + title10[index10_2];
		System.out.println(listTitle);
		/*
		 * System.out.println(Arrays.toString(title1));
		 * System.out.println(Arrays.toString(title2));
		 * System.out.println(Arrays.toString(title3));
		 * System.out.println(Arrays.toString(title4));
		 * System.out.println(Arrays.toString(title5));
		 */
		// System.out.println(listTitle);
		return listTitle;
	}
}
