package com.xinyue.serverUI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.xinyue.exception.StudentExistException;
import com.xinyue.model.Title;
import com.xinyue.service.TitleManage;
import com.xinyue.serviceimp.TitleManageImp;
import com.xinyue.util.ImportTitle;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class TitleManageFrame extends javax.swing.JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel jPanel1;
	private JButton jButton1;
	private JButton jButton4;
	private JScrollPane jScrollPane1;
	private JButton jButton5;
	private JButton jButton3;
	private JButton jButton2;
	private JTable jTable1;
	private String[][] listTitle;
	// ע��TitleManage
	private static TitleManage titleManage = new TitleManageImp();

	{
		// Set Look & Feel
		try {
			javax.swing.UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Auto-generated main method to display this JFrame
	 */

	public static String[][] titleList() {

		List<Title> listTitle = titleManage.findAll();
		int size = listTitle.size();
		String titleStr[][] = new String[size][7];
		for (int i = 0; i < listTitle.size(); i++) {
			Title title = listTitle.get(i);
			titleStr[i][0] = title.getTid() + "";
			titleStr[i][1] = title.getCourse();
			titleStr[i][2] = title.getQuestion();
			titleStr[i][3] = title.getOption();
			titleStr[i][4] = title.getKey();
			titleStr[i][5] = title.getLevel() + "";
			titleStr[i][6] = title.getScore() + "";
		}

		return titleStr;
	}

	public TitleManageFrame() {
		super();
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				{
					jScrollPane1 = new JScrollPane();
					jPanel1.add(jScrollPane1);
					jScrollPane1.setBounds(7, 25, 685, 337);
					{
						listTitle = titleList();
						TableModel jTable1Model = new DefaultTableModel(
								listTitle,
								new String[] { "��Ŀ���", "�����γ�", "��Ŀ����", "��Ŀѡ��",
										"��Ŀ��", "��Ŀ�ȼ�", "��Ŀ����" });

						jTable1 = new JTable();
						jScrollPane1.setViewportView(jTable1);
						jTable1.setModel(jTable1Model);
						jTable1.setBounds(7, 25, 685, 337);
					}
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("ɾ��");
					jButton1.setBounds(482, 391, 80, 28);
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u624b\u52a8\u589e\u52a0");
					jButton2.setBounds(190, 391, 89, 28);
				}
				{
					jButton3 = new JButton();
					jPanel1.add(jButton3);
					jButton3.setText("�޸�");
					jButton3.setBounds(342, 391, 77, 28);
				}
				{
					jButton4 = new JButton();
					jPanel1.add(jButton4);
					jButton4.setText("\u5237\u65b0");
					jButton4.setBounds(609, 391, 74, 28);
				}
				{
					jButton5 = new JButton();
					jPanel1.add(jButton5);
					jButton5.setText("\u6279\u91cf\u5bfc\u5165");
					jButton5.setBounds(54, 391, 86, 28);
				}
			}
			pack();
			this.setSize(715, 468);
			setLocationRelativeTo(null);
			setVisible(true);
			// ����������¼�
			jButton5.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub

					ImportTitle iu = new ImportTitle();
					try {

						titleManage.setAuto_increment(1);
						iu.insertTitle(iu.getTitles());

						listTitle = titleList();
						TableModel jTable1Model = new DefaultTableModel(
								listTitle, new String[] { "��Ŀ���", "�����γ�","��Ŀ����",
										"��Ŀѡ��", "��Ŀ��", "��Ŀ�ȼ�", "��Ŀ����" });
						jTable1.setModel(jTable1Model);

					} catch (StudentExistException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			// ɾ�����¼�
			jButton1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					int selectRows = jTable1.getSelectedRows().length;// ȡ���û���ѡ�е�����
					DefaultTableModel tableModel = (DefaultTableModel) jTable1
							.getModel();
					if (selectRows >= 1) {
						int selRowIndexs[] = jTable1.getSelectedRows();// �û���ѡ�е�����
						for (int i = 0; i < selRowIndexs.length; i++) {
							// ��tableModel.getValueAt(row, column)ȡ��Ԫ������
							String cellValue = (String) tableModel.getValueAt(
									selRowIndexs[i], 0);
							int tid = Integer.parseInt(cellValue);
							titleManage.deleteById(tid);

							listTitle = titleList();
							TableModel jTable1Model = new DefaultTableModel(
									listTitle, new String[] { "��Ŀ���","�����γ�", "��Ŀ����",
											"��Ŀѡ��", "��Ŀ��", "��Ŀ�ȼ�", "��Ŀ����" });
							jTable1.setModel(jTable1Model);
						}
					}

				}
			});
			// ���ӵ��¼�
			jButton2.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub

					new AddTitleFrame();

				}
			});

			// �޸ĵ��¼�
			jButton3.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					int selectRows = jTable1.getSelectedRow();// ȡ���û���ѡ��
					DefaultTableModel tableModel = (DefaultTableModel) jTable1
							.getModel();
					String cellValue = (String) tableModel.getValueAt(
							selectRows, 0);
					String course = (String) tableModel
							.getValueAt(selectRows, 1);
					int tid = Integer.parseInt(cellValue);
					String question = (String) tableModel.getValueAt(
							selectRows, 2);
					String option = (String) tableModel.getValueAt(selectRows,
							3);
					String key = (String) tableModel.getValueAt(selectRows, 4);
					int level = Integer.parseInt((String) tableModel
							.getValueAt(selectRows, 5));
					int score = Integer.parseInt((String) tableModel
							.getValueAt(selectRows, 6));

					Title title = new Title();
					title.setTid(tid);
					title.setQuestion(question);
					title.setOption(option);
					title.setKey(key);
					title.setLevel(level);
					title.setScore(score);
					title.setCourse(course);

					new UpdateTitleFrame(title);

				}
			});

			// ˢ�µ��¼�
			jButton4.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub

					listTitle = titleList();
					TableModel jTable1Model = new DefaultTableModel(listTitle,
							new String[] { "��Ŀ���", "�����γ�","��Ŀ����", "��Ŀѡ��", "��Ŀ��",
									"��Ŀ�ȼ�", "��Ŀ����" });
					jTable1.setModel(jTable1Model);
				}
			});
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}

	public JTable getjTable1() {
		return jTable1;
	}

	public void setjTable1(JTable jTable1) {
		this.jTable1 = jTable1;
	}
}
