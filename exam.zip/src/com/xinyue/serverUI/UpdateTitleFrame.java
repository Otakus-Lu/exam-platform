package com.xinyue.serverUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.xinyue.model.Title;
import com.xinyue.service.TitleManage;
import com.xinyue.serviceimp.TitleManageImp;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class UpdateTitleFrame extends javax.swing.JFrame {
	private static final long serialVersionUID = 1L;

	/**
	 * Auto-generated main method to display this JFrame
	 */

	private JButton jButton1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JComboBox jComboBox1;
	private JComboBox jComboBox5;
	private JComboBox jComboBox4;
	private JComboBox jComboBox3;
	private JLabel jLabel1;
	private JTextArea jTextArea1;
	private JTextField jTextField2;
	private JButton jButton2;
	private JLabel jLabel10;
	private JLabel jLabel7;
	private JLabel jLabel8;
	private JPanel jPanel1;
	private Title title;

	/**
	 * 
	 */

	// ע��Service
	private TitleManage titleManage = new TitleManageImp();

	public UpdateTitleFrame(Title title) {
		super();
		this.title = title;
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1);
				jPanel1.setBounds(0, 0, 605, 392);
				jPanel1.setLayout(null);
				{
					jLabel7 = new JLabel();
					jPanel1.add(jLabel7);
					jLabel7.setText("\u9898\u76ee\u9009\u9879");
					jLabel7.setBounds(63, 175, 70, 14);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u4fee\u6539");
					jButton1.setBounds(223, 341, 67, 24);
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u6e05\u7a7a");
					jButton2.setBounds(339, 341, 68, 24);
				}
				{
					jLabel8 = new JLabel();
					jPanel1.add(jLabel8);
					jLabel8.setText("\u9898\u76ee\u7b54\u6848");
					jLabel8.setBounds(63, 217, 70, 14);
				}
				{
					jLabel10 = new JLabel();
					jPanel1.add(jLabel10);
					jLabel10.setText("\u9898\u76ee\u96be\u5ea6");
					jLabel10.setBounds(63, 259, 70, 14);
					jLabel10.setOpaque(true);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u9898\u76ee\u5185\u5bb9  ");
					jLabel2.setBounds(60, 45, 91, 33);
					jLabel2.setOpaque(true);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setText(title.getOption());
					jTextField2.setBounds(168, 166, 329, 30);
				}
				{
					jTextArea1 = new JTextArea();
					jPanel1.add(jTextArea1);
					jTextArea1.setText(title.getQuestion());
					jTextArea1.setBounds(169, 23, 327, 72);
				}
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u9898\u76ee\u5206\u6570");
					jLabel1.setOpaque(true);
					jLabel1.setBounds(63, 294, 70, 14);
				}

				{
					ComboBoxModel jComboBox3Model = new DefaultComboBoxModel(
							new String[] { "A", "B", "C", "D" });
					jComboBox3 = new JComboBox();
					jPanel1.add(jComboBox3);
					System.out.println(title.getKey());
					jComboBox3.setSelectedItem(title.getKey());
					jComboBox3.setModel(jComboBox3Model);
					jComboBox3.setBounds(168, 217, 98, 21);
				}
				{
					ComboBoxModel jComboBox4Model = new DefaultComboBoxModel(
							new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
					jComboBox4 = new JComboBox();
					jPanel1.add(jComboBox4);
					jComboBox4.setModel(jComboBox4Model);
					jComboBox4.setBounds(168, 259, 98, 21);
				}
				{
					ComboBoxModel jComboBox5Model = new DefaultComboBoxModel(
							new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
									12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
									23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
									34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44,
									45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
									56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66,
									67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
									78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88,
									89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
									100 });
					jComboBox5 = new JComboBox();
					jPanel1.add(jComboBox5);
					jComboBox5.setModel(jComboBox5Model);
					jComboBox5.setBounds(168, 294, 98, 21);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u6240\u5c5e\u8bfe\u7a0b");
					jLabel3.setBounds(63, 126, 70, 14);
				}
				{
					ComboBoxModel jComboBox1Model = 
						new DefaultComboBoxModel(
								new String[] {"JAVA SE", "MySql", "��ɢ��ѧ", "����ϵͳ",
										"���������", "����ԭ��", "C����", "C++", "�������" });
					jComboBox1 = new JComboBox();
					jPanel1.add(jComboBox1);
					jComboBox1.setModel(jComboBox1Model);
					jComboBox1.setBounds(168, 119, 98, 21);
				}
			}
			pack();
			this.setSize(621, 430);

			setLocationRelativeTo(null);
			setVisible(true);

			// �޸������¼�
			jButton1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					int tid = title.getTid();
					String question = jTextArea1.getText();
					String option = jTextField2.getText();
					String key = (String) jComboBox3.getSelectedItem();
					String course = (String) jComboBox1.getSelectedItem();
					int level = (Integer) jComboBox4.getSelectedItem();
					int score = (Integer) jComboBox5.getSelectedItem();
					Title title1 = new Title();
					title1.setTid(tid);
					title1.setQuestion(question);
					title1.setOption(option);
					title1.setKey(key);
					title1.setLevel(level);
					title1.setScore(score);
					title1.setCourse(course);

					titleManage.update(title1);
					JOptionPane
							.showMessageDialog(UpdateTitleFrame.this, "update success!!!");
				}
			});
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}

	}

}
