package com.xinyue.service;

import java.util.List;

import com.xinyue.model.Paper;

public interface PaperManage {
	public abstract void save(Paper paper);

	public abstract void delete(Paper paper);

	public abstract void update(Paper paper);

	public abstract Paper findById(int pid);

	public abstract List<Paper> findAll();

	public abstract void deleteById(int tid);
}
