package com.xinyue.service;

import java.util.List;

import com.xinyue.model.Title;

public interface TitleManage {
	public abstract void save(Title title);

	public abstract void delete(Title title);

	public abstract void update(Title title);

	public abstract Title findById(int tid);

	public abstract List<Title> findAll();

	public void deleteById(int tid);

	public abstract void setAuto_increment(int id);

	public abstract List<Title> findByCourse(String course);
}
