package com.xinyue.service;

import java.util.List;

import com.xinyue.exception.StudentExistException;
import com.xinyue.model.User;


public interface UserManage {

	public abstract void save(User user)throws StudentExistException;

	public abstract void delete(User user);

	public abstract void update(User user);

	public abstract User findById(int uid);

	public abstract List<User> findAll();

	public abstract void deleteById(int tid);
	
	public abstract void setAuto_increment(int id);
	
	
}
