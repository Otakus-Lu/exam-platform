package com.Exam.bean;

public class QuestionType {// ��������
	private int id;
	private String qName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQName() {
		return qName;
	}
	public void setQName(String name) {
		qName = name;
	}
	
}
