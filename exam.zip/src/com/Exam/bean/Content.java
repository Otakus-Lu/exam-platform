package com.Exam.bean;

public class Content {
private int id;
private String content;
private String anwser;
private int userId;
private int grade;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getGrade() {
	return grade;
}
public void setGrade(int grade) {
	this.grade = grade;
}
public String getAnwser() {
	return anwser;
}
public void setAnwser(String anwser) {
	this.anwser = anwser;
}


}
