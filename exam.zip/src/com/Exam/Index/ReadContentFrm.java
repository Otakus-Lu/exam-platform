package com.Exam.Index;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.Exam.bean.Grade;
import com.Exam.dao.ContentDao;
import com.Exam.dao.FindGrade;

public class ReadContentFrm extends JFrame {

	private JPanel contentPane;
	private JTextField tf1;
	private JTextField tf2;
	JTextArea ta1 ;
	ContentDao cd=new ContentDao();
	FindGrade fd=new FindGrade();
	private JTextField txtLilei;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReadContentFrm frame = new ReadContentFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReadContentFrm() {
		setTitle("\u9605\u5377");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 775, 467);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		JLabel label = new JLabel("\u95EE\u9898");
		
		JLabel label_1 = new JLabel("\u7B54\u6848");
		
		tf1 = new JTextField();
		tf1.setText("\u4EC0\u4E48\u662FMVC\u67B6\u6784\uFF1F");
		tf1.setColumns(10);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int grade=Integer.parseInt(tf2.getText());
				cd.updateGradeDBbean(grade);
				Grade g1=new Grade();
				g1.setId(14);
				Grade g=fd.getGradeID(g1);
				int gg=grade+g.getBatsisResult();
				fd.update(14, gg);
				//JOptionPane.showMessageDialog(this, "�ɹ�","��Ϣ�Ի���", JOptionPane.WARNING_MESSAGE);
			}
		});
		
	    ta1 = new JTextArea();
	    ta1.setRows(10);
	    ta1.setLineWrap(true);
	    ta1.setText("\u7ECF\u5178MVC\u6A21\u5F0F\u4E2D\uFF0CM\u662F\u6307\u4E1A\u52A1\u6A21\u578B\uFF0CV\u662F\u6307\u7528\u6237\u754C\u9762\uFF0CC\u5219\u662F\u63A7\u5236\u5668\uFF0C\u4F7F\u7528MVC\u7684\u76EE\u7684\u662F\u5C06M\u548CV\u7684\u5B9E\u73B0\u4EE3\u7801\u5206\u79BB\uFF0C\u4ECE\u800C\u4F7F\u540C\u4E00\u4E2A\u7A0B\u5E8F\u53EF\u4EE5\u4F7F\u7528\u4E0D\u540C\u7684\u8868\u73B0\u5F62\u5F0F\u3002\u5176\u4E2D\uFF0CView\u7684\u5B9A\u4E49\u6BD4\u8F83\u6E05\u6670\uFF0C\u5C31\u662F\u7528\u6237\u754C\u9762\u3002");
		
		JLabel label_2 = new JLabel("\u5206\u6570");
		
		tf2 = new JTextField();
		tf2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u8003\u751F\u59D3\u540D");
		
		txtLilei = new JTextField();
		txtLilei.setText("lilei");
		txtLilei.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(21)
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
								.addComponent(label)
								.addComponent(label_1))
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(tf1, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(tf2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addGap(69)
									.addComponent(button))
								.addComponent(ta1)))
						.addGroup(gl_panel.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel)
							.addGap(30)
							.addComponent(txtLilei, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(68, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(tf1, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(76)
							.addComponent(label_1))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(45)
							.addComponent(ta1, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(txtLilei, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(tf2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button))
					.addGap(44))
		);
		panel.setLayout(gl_panel);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(56, Short.MAX_VALUE)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 655, GroupLayout.PREFERRED_SIZE)
					.addGap(36))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 408, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
