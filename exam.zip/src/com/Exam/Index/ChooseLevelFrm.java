package com.Exam.Index;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.Exam.bean.User;
import com.Exam.dao.FindGrade;
import com.Exam.dao.InsertUserDao;
import com.Exam.dao.MyFindUserDao;
import com.Exam.student.ExamPage;

public class ChooseLevelFrm extends JFrame {

	private JPanel contentPane;
	private JComboBox cb;
	FindGrade fd=new FindGrade();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChooseLevelFrm frame = new ChooseLevelFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChooseLevelFrm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		cb = new JComboBox();
		cb.setModel(new DefaultComboBoxModel(new String[] {"\u7B80\u5355", "\u56F0\u96BE", "\u9B54\u9B3C"}));
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u9009\u62E9\u96BE\u5EA6");
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u8003\u8BD5");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			int id1=cb.getSelectedIndex();// 0 1 2
			java.io.File file = new java.io.File("save.txt");
			try{
				java.io.FileInputStream in = new java.io.FileInputStream(file);		
				byte byt[] = new byte[1024];					
				int len = in.read(byt);						
				String strid = new String(byt,0,len);	
				int id = Integer.parseInt(strid);
				MyFindUserDao findUser = new MyFindUserDao();
				User user = new User();
				user.setId(id);		
				User use = findUser.getUserID(user);
				System.out.println("AAA"+use.getId());
				if(use.getHaveIn() == 0){
					ExamPage exampage = new ExamPage();
					exampage.setVisible(true);
					InsertUserDao insertUser = new InsertUserDao();
					use.setHaveIn(0);/*yezi-2013-5-15*/
					boolean b = insertUser.setUserHaveIn(use);	
				}
				else if(use.getHaveIn() == 1){
					//JOptionPane.showMessageDialog(this, "���Ѿ��μ��꿼���ˣ�", "��Ϣ�Ի���",JOptionPane.WARNING_MESSAGE);
				}
				in.close();	
			}catch (Exception e) {
				e.printStackTrace();							
			}
			
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(51)
					.addComponent(lblNewLabel)
					.addGap(18)
					.addComponent(cb, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnNewButton)
					.addContainerGap(77, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(63)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(cb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addContainerGap(156, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
