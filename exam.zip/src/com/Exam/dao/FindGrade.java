package com.Exam.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Exam.bean.Grade;
import com.Exam.sql.GetConn;
public class FindGrade {
	GetConn getConn = new GetConn();
	private Connection conn = getConn.getConnection();
	//��������ѧ���û�	
	public List findGrade() {
		String strSql = "select * from tb_grade";
		Statement pstmt = null;
		ResultSet rs = null;
		List lstList = new ArrayList();
		try {
			pstmt = conn.createStatement();
			rs = pstmt.executeQuery(strSql);
			while (rs.next()) {
				Grade grade = new Grade();
				grade.setId(rs.getInt("id"));
				grade.setUserName(rs.getString("userName"));
				grade.setRadioResult(rs.getInt("radioResult"));
				grade.setFullResule(rs.getInt("fullResule"));
				grade.setEsitResult(rs.getInt("esitResult"));
				grade.setReadResult(rs.getInt("readResult"));/*yezi-2013_5-14*/
				grade.setBatsisResult(rs.getInt("batsisResult"));
				grade.setDate(rs.getString("date"));				
				lstList.add(grade);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					rs.close();
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return lstList;
	}
	//��id�Ų�ѯ�ɼ�����
/**
 * @param grade ��Ӧ���ֱ�Java bean Grade����
 * @return		Grade����
 */
public boolean update(int id,int BatsisResult){
		String sql = "update tb_grade set BatsisResult=? where id=?";
		try {
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1,BatsisResult );
			preparedStatement.setInt(2, id);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
public Grade getGradeID(Grade grade){
	String strSql = "select * from tb_grade where id=?";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	try {
		pstmt = conn.prepareStatement(strSql);
		pstmt.setInt(1, grade.getId());
		rs = pstmt.executeQuery();
		while (rs.next()) {
			grade.setId(rs.getInt("id"));
			grade.setUserName(rs.getString("userName"));
			grade.setRadioResult(rs.getInt("radioResult"));
			grade.setFullResule(rs.getInt("fullResule"));
			grade.setEsitResult(rs.getInt("esitResult"));
			grade.setReadResult(rs.getInt("readResult"));/*yezi-2013_5-14*/
			grade.setBatsisResult(rs.getInt("batsisResult"));
			grade.setDate(rs.getString("date"));
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			if (pstmt != null) {
				rs.close();
				pstmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	return grade;
}

	//�������������ҿ��Գɼ�����
/**
 * @param grade	�����ݱ�tb_stat��Ӧ��java bean Stat����
 * @return	Stat����
 */
public Grade getGradeName(Grade grade){
	String strSql = "select * from tb_grade where userName=?";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	try {
		pstmt = conn.prepareStatement(strSql);
		pstmt.setString(1, grade.getUserName());
		rs = pstmt.executeQuery();
		while (rs.next()) {
			grade.setId(rs.getInt("id"));
			grade.setUserName(rs.getString("userName"));
			grade.setRadioResult(rs.getInt("radioResult"));
			grade.setFullResule(rs.getInt("fullResule"));
			grade.setEsitResult(rs.getInt("esitResult"));
			grade.setReadResult(rs.getInt("readResult"));/*yezi-2013_5-14*/
			grade.setBatsisResult(rs.getInt("batsisResult"));
			grade.setDate(rs.getString("date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					rs.close();
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return grade;
	}

public int num1(){
	int sum=0;
	String strSql = "select * from tb_grade where batsisResult<60";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	try {
		pstmt = conn.prepareStatement(strSql);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			sum++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					rs.close();
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
	}
public int num2(){
	int sum=0;
	String strSql = "select * from tb_grade where batsisResult>=60";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	try {
		pstmt = conn.prepareStatement(strSql);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			sum++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					rs.close();
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
	}
public static void main(String[] args) {
	FindGrade fg = new FindGrade();
	Grade f = new Grade();
	f.setUserName("kk");
	Grade g = fg.getGradeName(f);
	System.out.println(g.getId());
}
}
