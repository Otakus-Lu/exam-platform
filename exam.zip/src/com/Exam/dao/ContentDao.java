package com.Exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.Exam.bean.Content;
import com.Exam.sql.GetConn;

public class ContentDao {
	GetConn getConn = new GetConn();
	private Connection conn = getConn.getConnection();
	public boolean addContent(Content c) {
		boolean blnrec = true;
		String strSql = "insert into tb_content"
				+ " values(null,?,?,?,?)";
		System.out.println(strSql);
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(strSql);
			pstmt.setString(1, c.getContent());
			
			pstmt.setInt(2, c.getUserId());
			pstmt.setInt(3, c.getGrade());
			pstmt.setString(4, c.getAnwser());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			blnrec = false;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return blnrec;
	}
	public boolean updateGradeDBbean(int  grade) {
		boolean blnrec = true;
		String strSql = "update tb_content set grade=? where id=1";
		System.out.println(strSql);
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(strSql);
			pstmt.setInt(1, grade);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			blnrec = false;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return blnrec;
	} 
}
