package com.Exam.controller;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import com.Exam.dao.FindGrade;

import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.Font;

public class bar1 extends JFrame {

	private JPanel viewPanel;
	private ChartPanel cp;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bar1 frame = new bar1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	ChartPanel frame1;

	/**
	 * Create the frame.
	 */
	public bar1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 523, 364);
		viewPanel = new JPanel();
		viewPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(viewPanel);
		
		JPanel Jpanel = new JPanel();
		
		JButton btnNewButton = new JButton("\u663E\u793A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearPanel();
				drawBar();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(viewPanel);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(37, Short.MAX_VALUE)
					.addComponent(Jpanel, GroupLayout.PREFERRED_SIZE, 432, GroupLayout.PREFERRED_SIZE)
					.addGap(26))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnNewButton)
					.addContainerGap(368, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(Jpanel, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNewButton)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		GroupLayout gl_Jpanel = new GroupLayout(Jpanel);
		gl_Jpanel.setHorizontalGroup(
			gl_Jpanel.createParallelGroup(Alignment.LEADING)
				.addGap(0, 432, Short.MAX_VALUE)
		);
		gl_Jpanel.setVerticalGroup(
			gl_Jpanel.createParallelGroup(Alignment.LEADING)
				.addGap(0, 247, Short.MAX_VALUE)
		);
		Jpanel.setLayout(gl_Jpanel);
		viewPanel.setLayout(gl_contentPane);
        
	
 
        
	}
	
public void drawBar() {
	FindGrade fd=new FindGrade();
	int num1=fd.num1();
	int num2=fd.num2();
	setLanuage();
	DefaultCategoryDataset dataSet = new DefaultCategoryDataset();//����һ�����ݼ�
	dataSet.addValue(num1, "�ɼ�", "����������");//��������
	dataSet.addValue(num2, "�ɼ�", "��������");
	//dataSet.addValue(66, "2018-04-19", "������");
	//����һ��chart���󣬰����ݼ��Ž�ȥ
	JFreeChart chart = ChartFactory.createBarChart3D("ѧ���ɼ�ͳ��", "�ɼ�", "����", dataSet, PlotOrientation.VERTICAL, true, false, false);
	//����һ��ͼ��panel
	cp=new ChartPanel(chart);
	//viewPanel.setPreferredSize(new Dimension(100,100));
	//W��ͼ��panel���ӵ�Ҫ��ʾ��panel��
	viewPanel.add(cp,BorderLayout.CENTER);
	viewPanel.setLayout(new FlowLayout());
	viewPanel.updateUI();
	viewPanel.repaint();
}
private void clearPanel(){
	viewPanel.removeAll();
	viewPanel.updateUI();
	viewPanel.repaint();
}
private void setLanuage(){
	//����������ʽ  
	   StandardChartTheme standardChartTheme=new StandardChartTheme("CN");  
	   //���ñ�������  
	   standardChartTheme.setExtraLargeFont(new Font("����",Font.BOLD,20));  
	   //����ͼ��������  
	   standardChartTheme.setRegularFont(new Font("����",Font.PLAIN,15));  
	   //�������������  
	   standardChartTheme.setLargeFont(new Font("����",Font.PLAIN,15));  
	   //Ӧ��������ʽ  
	   ChartFactory.setChartTheme(standardChartTheme);
}
}
